// GHI Electronics Endpoint for C++: the board's hardware with the same API
// as .NET (System.Device.Gpio, I2c, Spi, Pwm, Analog; System.IO.Ports;
// Iot.Device.SocketCan; .NET IoT's RtcBase; TinyCLR's DAC and watchdog;
// SD cards and USB drives; USB devices; .NET IoT's SoundDevice).
//
//   #include <endpoint.h>
//   using namespace GHIElectronics::Endpoint::Core;
//   using namespace GHIElectronics::Endpoint::Devices::Gpio;
//
//   GpioController gpio;
//   gpio.OpenPin(EPM815::Gpio::Pin::PC0, PinMode::Output);
//   gpio.Write(EPM815::Gpio::Pin::PC0, PinValue::High);
//
// Link the program with libendpoint.a. Errors are exceptions with the .NET
// names (Core::InvalidOperationException...), which are also the standard
// C++ ones (std::runtime_error...).
#pragma once

#include "endpoint/Adc.h"
#include "endpoint/Camera.h"
#include "endpoint/Can.h"
#include "endpoint/Core.h"
#include "endpoint/Dac.h"
#include "endpoint/Display.h"
#include "endpoint/Drawing.h"
// EPDomino24 board aliases + EPN128 (MA35D0, Chili Pro) and EPN256 (MA35D1)
// pin names plus their pay-for-use peripheral helpers — pulled in by
// default so sample code can write EPN256::StorageController::UsbHostMassStorage
// without an extra include. (Mirrors the .NET and Python APIs, where these
// are reachable through the top-level Core import.)
#include "endpoint/EPDomino24.h"
#include "endpoint/EPN128.h"
#include "endpoint/EPN256.h"
#include "endpoint/Gpio.h"
#include "endpoint/I2c.h"
#include "endpoint/Network.h"
#include "endpoint/Ports.h"
#include "endpoint/Pwm.h"
#include "endpoint/Rtc.h"
#include "endpoint/Sound.h"
#include "endpoint/Spi.h"
#include "endpoint/Storage.h"
#include "endpoint/Touch.h"
#include "endpoint/UI.h"
#include "endpoint/UsbHost.h"
#include "endpoint/Version.h"
#include "endpoint/Watchdog.h"
