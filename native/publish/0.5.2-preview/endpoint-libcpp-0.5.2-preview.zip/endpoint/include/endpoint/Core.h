// GHI Electronics Endpoint for C++: the EPM815's pins, buses and ports, and
// the errors the Endpoint classes throw. The same as .NET's
// GHIElectronics.Endpoint.Core:
//
//   using namespace GHIElectronics::Endpoint::Core;
//   EPM815::I2c::Initialize(EPM815::I2c::I2c1);
#pragma once

#include <cctype>
#include <fstream>
#include <functional>
#include <iterator>
#include <map>
#include <mutex>
#include <stdexcept>
#include <string>
#include <vector>

#include "detail/CApi.h"

namespace GHIElectronics::Endpoint::Core {

// The errors: the same names as the .NET exceptions, and also the matching
// standard C++ ones (an ArgumentException is a std::invalid_argument)
class ArgumentException : public std::invalid_argument {
public:
    using std::invalid_argument::invalid_argument;
};
class ArgumentOutOfRangeException : public ArgumentException {
public:
    using ArgumentException::ArgumentException;
};
class InvalidOperationException : public std::runtime_error {
public:
    using std::runtime_error::runtime_error;
};
class IOException : public std::runtime_error {
public:
    using std::runtime_error::runtime_error;
};
class NotSupportedException : public std::runtime_error {
public:
    using std::runtime_error::runtime_error;
};
class ObjectDisposedException : public InvalidOperationException {
public:
    using InvalidOperationException::InvalidOperationException;
};
class NotImplementedException : public std::logic_error {
public:
    using std::logic_error::logic_error;
};
class TimeoutException : public std::runtime_error {
public:
    using std::runtime_error::runtime_error;
};

// A .NET-style event: handlers are added with += and removed with -=.
// C++ cannot compare functions, so += gives an id for -=:
//
//   int id = (usb.ConnectionChanged += handler);
//   usb.ConnectionChanged -= id;
//
// The handlers run on the thread that raises the event (the library's).
template <typename... Args>
class Event {
public:
    using Handler = std::function<void(Args...)>;

    Event() = default;
    Event(const Event&) = delete;
    Event& operator=(const Event&) = delete;

    int operator+=(Handler handler) {
        std::lock_guard lock(mutex_);
        handlers_[++lastId_] = std::move(handler);
        return lastId_;
    }

    Event& operator-=(int id) {
        std::lock_guard lock(mutex_);
        handlers_.erase(id);
        return *this;
    }

    // Raises the event: every handler, in the order they were added (used by the library)
    void operator()(Args... args) const {
        std::vector<Handler> handlers;
        {
            std::lock_guard lock(mutex_);
            for (const auto& [id, handler] : handlers_) {
                handlers.push_back(handler);
            }
        }
        for (const auto& handler : handlers) {
            handler(args...);
        }
    }

private:
    mutable std::mutex mutex_;
    std::map<int, Handler> handlers_;
    int lastId_ = 0;
};

// A device connected or disconnected (StorageController, UsbHostController)
enum class DeviceConnectionStatus {
    Disconnected = 0,
    Connected = 1,
    Bad = 2,  // a drive with no file system the board reads (format it as FAT32 or exFAT)
};

// The chip the library is running on, read once from
// /proc/device-tree/model + /proc/device-tree/compatible at first use.
// Mirrors .NET's GHIElectronics.Endpoint.Core.Internal.ChipDetect; chip
// dispatch inside the library (pin muxing, device paths) uses this.
enum class Chip {
    Unknown = 0,  // dev host without a Linux device tree
    Epm815 = 1,   // STM32MP153 (EPM815 family)
    Epn256 = 2,   // Nuvoton MA35D1 (EPN256 family)
    Epn128 = 3,   // Nuvoton MA35D0 (EPN128 / Chili Pro)
};

namespace ChipDetect {

namespace detail {

// Read a /proc/device-tree node file and strip the trailing NUL that the
// kernel appends, so Contains-style substring matches behave intuitively.
inline std::string ReadDtNodeText(const char* path) {
    std::ifstream f(path, std::ios::binary);
    if (!f) return {};
    std::string s((std::istreambuf_iterator<char>(f)), std::istreambuf_iterator<char>());
    while (!s.empty() && s.back() == '\0') s.pop_back();
    return s;
}

inline bool Contains(const std::string& haystack, const char* needle) {
    // Case-insensitive substring match: /proc/device-tree/model is mixed case.
    std::string h; h.reserve(haystack.size());
    for (char c : haystack) h.push_back(static_cast<char>(std::tolower(static_cast<unsigned char>(c))));
    std::string n;
    for (const char* p = needle; *p; ++p) n.push_back(static_cast<char>(std::tolower(static_cast<unsigned char>(*p))));
    return h.find(n) != std::string::npos;
}

inline Chip Detect() {
    // /proc/device-tree/model carries the board/SoC name verbatim ("Nuvoton
    // MA35D05K-IoT" on Chili Pro, "Nuvoton MA35D1 SoM ..." on EPN256). Use
    // it first because /proc/device-tree/compatible on MA35D0 reports just
    // "nuvoton,ma35d1" - the family string - which would send MA35D0 down
    // the MA35D1 path. Check "MA35D0" first (matches "MA35D05K"/"MA35D06K")
    // before "MA35D1" fallback.
    std::string model = ReadDtNodeText("/proc/device-tree/model");
    if (!model.empty()) {
        if (Contains(model, "MA35D0")) return Chip::Epn128;
        if (Contains(model, "MA35D1")) return Chip::Epn256;
        if (Contains(model, "STM32MP15")) return Chip::Epm815;
    }
    std::string compat = ReadDtNodeText("/proc/device-tree/compatible");
    if (!compat.empty()) {
        if (Contains(compat, "ma35d0")) return Chip::Epn128;
        if (Contains(compat, "ma35d1")) return Chip::Epn256;
        if (Contains(compat, "stm32mp15")) return Chip::Epm815;
    }
    return Chip::Unknown;
}

}  // namespace detail

// The detected chip, cached for the life of the process (Meyers singleton).
// Thread-safe one-time init on first call.
inline Chip Current() {
    static const Chip chip = detail::Detect();
    return chip;
}

// True for any Nuvoton MA35 chip (EPN256 or EPN128).
inline bool IsMa35() { return Current() == Chip::Epn256 || Current() == Chip::Epn128; }

// True for the STM32MP1 family (EPM815).
inline bool IsStm32Mp1() { return Current() == Chip::Epm815; }

}  // namespace ChipDetect

namespace detail {

// Throws the error libendpoint reported (its kind and message)
[[noreturn]] inline void Throw(int kind) {
    std::string message = endpoint_last_error();
    switch (kind) {
        case 1: throw ArgumentException(message);
        case 2: throw ArgumentOutOfRangeException(message);
        case 3: throw InvalidOperationException(message);
        case 5: throw NotSupportedException(message);
        case 6: throw ObjectDisposedException(message);
        case 7: throw NotImplementedException(message);
        case 8: throw TimeoutException(message);
        default: throw IOException(message);
    }
}

inline void Check(int result) {
    if (result != 0) {
        Throw(result);
    }
}

}  // namespace detail

// The EPM815 (STM32MP15x) module
struct EPM815 {
    // GPIO pins, for Devices::Gpio::GpioController
    struct Gpio {
        // The EPM815's pins: port * 16 + line, ports A to I, then Z
        struct Pin {
            static constexpr int PA0 = 0, PA1 = 1, PA2 = 2, PA3 = 3, PA4 = 4, PA5 = 5, PA6 = 6, PA7 = 7;
            static constexpr int PA8 = 8, PA9 = 9, PA10 = 10, PA11 = 11, PA12 = 12, PA13 = 13, PA14 = 14, PA15 = 15;
            static constexpr int PB0 = 16, PB1 = 17, PB2 = 18, PB3 = 19, PB4 = 20, PB5 = 21, PB6 = 22, PB7 = 23;
            static constexpr int PB8 = 24, PB9 = 25, PB10 = 26, PB11 = 27, PB12 = 28, PB13 = 29, PB14 = 30, PB15 = 31;
            static constexpr int PC0 = 32, PC1 = 33, PC2 = 34, PC3 = 35, PC4 = 36, PC5 = 37, PC6 = 38, PC7 = 39;
            static constexpr int PC8 = 40, PC9 = 41, PC10 = 42, PC11 = 43, PC12 = 44, PC13 = 45, PC14 = 46, PC15 = 47;
            static constexpr int PD0 = 48, PD1 = 49, PD2 = 50, PD3 = 51, PD4 = 52, PD5 = 53, PD6 = 54, PD7 = 55;
            static constexpr int PD8 = 56, PD9 = 57, PD10 = 58, PD11 = 59, PD12 = 60, PD13 = 61, PD14 = 62, PD15 = 63;
            static constexpr int PE0 = 64, PE1 = 65, PE2 = 66, PE3 = 67, PE4 = 68, PE5 = 69, PE6 = 70, PE7 = 71;
            static constexpr int PE8 = 72, PE9 = 73, PE10 = 74, PE11 = 75, PE12 = 76, PE13 = 77, PE14 = 78, PE15 = 79;
            static constexpr int PF0 = 80, PF1 = 81, PF2 = 82, PF3 = 83, PF4 = 84, PF5 = 85, PF6 = 86, PF7 = 87;
            static constexpr int PF8 = 88, PF9 = 89, PF10 = 90, PF11 = 91, PF12 = 92, PF13 = 93, PF14 = 94, PF15 = 95;
            static constexpr int PG0 = 96, PG1 = 97, PG2 = 98, PG3 = 99, PG4 = 100, PG5 = 101, PG6 = 102, PG7 = 103;
            static constexpr int PG8 = 104, PG9 = 105, PG10 = 106, PG11 = 107, PG12 = 108, PG13 = 109, PG14 = 110, PG15 = 111;
            static constexpr int PH0 = 112, PH1 = 113, PH2 = 114, PH3 = 115, PH4 = 116, PH5 = 117, PH6 = 118, PH7 = 119;
            static constexpr int PH8 = 120, PH9 = 121, PH10 = 122, PH11 = 123, PH12 = 124, PH13 = 125, PH14 = 126, PH15 = 127;
            static constexpr int PI0 = 128, PI1 = 129, PI2 = 130, PI3 = 131, PI4 = 132, PI5 = 133, PI6 = 134, PI7 = 135;
            static constexpr int PI8 = 136, PI9 = 137, PI10 = 138, PI11 = 139, PI12 = 140, PI13 = 141, PI14 = 142, PI15 = 143;
            static constexpr int PZ0 = 144, PZ1 = 145, PZ2 = 146, PZ3 = 147, PZ4 = 148, PZ5 = 149, PZ6 = 150, PZ7 = 151;
            static constexpr int NONE = -1;  // no pin
        };

        // The pin's name, for example "PC0"
        static std::string Name(int pin) {
            if (pin < 0 || pin > Pin::PZ7) {
                return "#" + std::to_string(pin);
            }
            int port = pin / 16;
            return std::string("P") + (port == 9 ? 'Z' : static_cast<char>('A' + port)) + std::to_string(pin % 16);
        }

        // Linux gpiochip number for the pin, as exposed under /dev/gpiochipN
        // and /sys/class/gpio/gpiochipN. Use with any libgpiod-based code
        // (including the system gpioset tool) that wants to drive one of the
        // module's pins without the full Driver path.
        // On EPM815 each port is its own gpiochip (A..I,Z = 0..9).
        static int GetChipId(int pin) { return pin / 16; }

        // Line number within the gpiochip (0 to 15 on EPM815). Pairs with
        // GetChipId for raw libgpiod access.
        static int GetLineId(int pin) { return pin % 16; }
    };

    // The I2C buses, for Devices::I2c:
    //   EPM815::I2c::Initialize(EPM815::I2c::I2c1);
    //   auto device = I2cDevice::Create(I2cConnectionSettings(EPM815::I2c::I2c1, 0x50));
    struct I2c {
        static constexpr int I2c1 = 0;  // PD12 (SCL), PD13 (SDA)
        static constexpr int I2c5 = 1;  // PZ4 (SCL), PZ5 (SDA)
        static constexpr int I2c4 = 2;  // PB6 (SCL), PF15 (SDA)
        static constexpr int I2c6 = 3;  // PD1 (SCL), PD0 (SDA)

        static constexpr int DefaultFrequency = 400'000;  // fast mode
        static constexpr int MinFrequency = 10'000;
        static constexpr int MaxFrequency = 1'000'000;    // fast mode plus

        // Connects the bus's pins (open drain, internal pull-ups on) and sets its speed
        static void Initialize(int bus, int frequency = DefaultFrequency) { detail::Check(endpoint_i2c_initialize(bus, frequency)); }
        // Gives the bus's pins back, as they were before Initialize
        static void UnInitialize(int bus) { detail::Check(endpoint_i2c_uninitialize(bus)); }
        // The bus speed in use, in Hz
        static int GetFrequency(int bus) {
            int frequency = 0;
            detail::Check(endpoint_i2c_get_frequency(bus, &frequency));
            return frequency;
        }
    };

    // The SPI buses, for Devices::Spi. Chip select is not driven by the bus: use any GPIO pin.
    struct Spi {
        static constexpr int Spi1 = 0;  // PZ0 (SCK), PZ1 (MISO), PZ2 (MOSI)
        static constexpr int Spi4 = 1;  // PE12 (SCK), PE13 (MISO), PE14 (MOSI)
        static constexpr int Spi5 = 2;  // PF7 (SCK), PF8 (MISO), PF9 (MOSI)

        static constexpr int DefaultBufferSize = 4096;  // the largest transfer when none is given

        // Connects the bus's pins and loads the SPI driver if needed. bufferSize
        // is the largest transfer: the first Initialize after boot decides it.
        static void Initialize(int bus, int bufferSize = DefaultBufferSize) { detail::Check(endpoint_spi_initialize(bus, bufferSize)); }
        static void UnInitialize(int bus) { detail::Check(endpoint_spi_uninitialize(bus)); }
    };

    // PWM pins, for Devices::Pwm::PwmChannel. Channels of one timer share its frequency.
    struct Pwm {
        struct Pin {
            static constexpr int PA8 = 8, PE11 = 75, PA10 = 10, PA11 = 11;  // TIM1 channels 1-4
            static constexpr int PA15 = 15, PB3 = 19, PA3 = 3;              // TIM2 channels 1, 2, 4
            static constexpr int PC6 = 38, PB5 = 21, PB0 = 16;              // TIM3 channels 1-3
            static constexpr int PD12 = 60, PB7 = 23, PD14 = 62, PD15 = 63; // TIM4 channels 1-4
            static constexpr int PA0 = 0, PH11 = 123, PH12 = 124, PI0 = 128;// TIM5 channels 1-4
            static constexpr int PI5 = 133, PI6 = 134, PI7 = 135, PI2 = 130;// TIM8 channels 1-4
            static constexpr int PH6 = 118, PH9 = 121;                      // TIM12 channels 1-2
            static constexpr int PA6 = 6;                                   // TIM13 channel 1
            static constexpr int PF9 = 89;                                  // TIM14 channel 1
            static constexpr int PE5 = 69, PE6 = 70;                        // TIM15 channels 1-2
            static constexpr int PB8 = 24;                                  // TIM16 channel 1
            static constexpr int PB9 = 25;                                  // TIM17 channel 1
        };

        // Connects the pin to its timer
        static void Initialize(int pin) { detail::Check(endpoint_pwm_initialize(pin)); }
        static void UnInitialize(int pin) { detail::Check(endpoint_pwm_uninitialize(pin)); }
        // The PWM chip of the pin's timer, for PwmChannel::Create
        static int GetChipId(int pin) {
            int chip = 0;
            detail::Check(endpoint_pwm_get_chip_id(pin, &chip));
            return chip;
        }
        // The pin's channel in its PWM chip, for PwmChannel::Create
        static int GetChannelId(int pin) {
            int channel = 0;
            detail::Check(endpoint_pwm_get_channel_id(pin, &channel));
            return channel;
        }
    };

    // The serial ports (UARTs), for Devices::Ports::SerialPort
    struct SerialPort {
        static constexpr const char* Uart1 = "/dev/ttySTM0";  // PZ7 (TX), PZ6 (RX), PA12 (RTS), PZ3 (CTS)
        static constexpr const char* Uart2 = "/dev/ttySTM1";  // PF5 (TX), PD6 (RX), PD4 (RTS), PD3 (CTS)
        static constexpr const char* Uart3 = "/dev/ttySTM2";  // PD8 (TX), PD9 (RX), PD12 (RTS), PD11 (CTS)
        static constexpr const char* Uart4 = "/dev/ttySTM3";  // PD1 (TX), PD0 (RX)
        static constexpr const char* Uart5 = "/dev/ttySTM4";  // PB13 (TX), PB12 (RX)
        static constexpr const char* Uart7 = "/dev/ttySTM6";  // PE8 (TX), PF6 (RX), PE9 (RTS), PE10 (CTS)
        static constexpr const char* Uart8 = "/dev/ttySTM7";  // PE1 (TX), PE0 (RX)

        // Connects the port's TX and RX pins, and RTS and CTS for hardware flow control
        static void Initialize(const std::string& portName, bool enableHardwareFlowControl = false) {
            detail::Check(endpoint_serialport_initialize(portName.c_str(), enableHardwareFlowControl ? 1 : 0));
        }
        static void UnInitialize(const std::string& portName) { detail::Check(endpoint_serialport_uninitialize(portName.c_str())); }
    };

    // The CAN ports, for Devices::Can::CanRaw. A port that goes bus-off after
    // too many errors restarts by itself after 100 ms.
    struct Can {
        static constexpr const char* Can1 = "can0";  // FDCAN1: PD1 (TX), PD0 (RX)
        static constexpr const char* Can2 = "can1";  // FDCAN2: PB13 (TX), PB12 (RX)
        static constexpr int MaxBitrate = 1'000'000;

        // Connects the port's pins, sets its bitrate and starts it
        static void Initialize(const std::string& port, int bitrate) { detail::Check(endpoint_can_initialize(port.c_str(), bitrate)); }
        // Stops the port and gives its pins back
        static void UnInitialize(const std::string& port) { detail::Check(endpoint_can_uninitialize(port.c_str())); }
    };

    // The analog inputs, for Devices::Adc::AdcController
    struct Adc {
        struct Pin {
            static constexpr int ANA0 = 0x1000, ANA1 = 0x1001;  // dedicated analog inputs, ADC1 channels 0 and 1
            static constexpr int PF11 = 91, PA6 = 6, PF12 = 92, PB0 = 16, PC0 = 32, PC3 = 35;  // ADC1 channels 2, 3, 6, 9, 10, 13
            static constexpr int PA3 = 3, PA0 = 0, PA4 = 4, PA5 = 5;                          // ADC1 channels 15, 16, 18, 19
            static constexpr int PF13 = 93, PF14 = 94;                                         // ADC2 channels 2 and 6
        };
    };

    // The analog outputs, for Devices::Dac (the same API as TinyCLR)
    struct Dac {
        static constexpr const char* Id = "EPM815.Dac";
        static constexpr int PA4 = 0;  // DAC channel 1
        static constexpr int PA5 = 1;  // DAC channel 2
    };

    // The watchdog, for Devices::Watchdog (the same API as TinyCLR)
    struct Watchdog {
        static constexpr const char* Id = "EPM815.Watchdog";
    };

    // SD cards and USB drives, for Devices::Storage
    struct StorageController {
        static constexpr const char* SdCard = "EPM815.StorageController.SdCard";
        static constexpr const char* UsbHostMassStorage = "EPM815.StorageController.UsbHostMassStorage";
    };
};

// The EPN256 (Nuvoton MA35D1) module. GPIO pin constants live here; the
// pay-for-use peripheral initializers (Spi, I2c, Pwm, Can, SerialPort,
// Adc, StorageController) live in endpoint/EPN256.h - include that too
// when you need them. Namespace, not struct, so EPN256.h can extend it.
namespace EPN256 {
    // GPIO pins, for Devices::Gpio::GpioController
    struct Gpio {
        // The EPN256's pins: port * 16 + line, ports A to N
        struct Pin {
            static constexpr int PA0 = 0, PA1 = 1, PA2 = 2, PA3 = 3, PA4 = 4, PA5 = 5, PA6 = 6, PA7 = 7;
            static constexpr int PA8 = 8, PA9 = 9, PA10 = 10, PA11 = 11, PA12 = 12, PA13 = 13, PA14 = 14, PA15 = 15;
            static constexpr int PB0 = 16, PB1 = 17, PB2 = 18, PB3 = 19, PB4 = 20, PB5 = 21, PB6 = 22, PB7 = 23;
            static constexpr int PB8 = 24, PB9 = 25, PB10 = 26, PB11 = 27, PB12 = 28, PB13 = 29, PB14 = 30, PB15 = 31;
            static constexpr int PC0 = 32, PC1 = 33, PC2 = 34, PC3 = 35, PC4 = 36, PC5 = 37, PC6 = 38, PC7 = 39;
            static constexpr int PC8 = 40, PC9 = 41, PC10 = 42, PC11 = 43, PC12 = 44, PC13 = 45, PC14 = 46, PC15 = 47;
            static constexpr int PD0 = 48, PD1 = 49, PD2 = 50, PD3 = 51, PD4 = 52, PD5 = 53, PD6 = 54, PD7 = 55;
            static constexpr int PD8 = 56, PD9 = 57, PD10 = 58, PD11 = 59, PD12 = 60, PD13 = 61, PD14 = 62, PD15 = 63;
            static constexpr int PE0 = 64, PE1 = 65, PE2 = 66, PE3 = 67, PE4 = 68, PE5 = 69, PE6 = 70, PE7 = 71;
            static constexpr int PE8 = 72, PE9 = 73, PE10 = 74, PE11 = 75, PE12 = 76, PE13 = 77, PE14 = 78, PE15 = 79;
            static constexpr int PF0 = 80, PF1 = 81, PF2 = 82, PF3 = 83, PF4 = 84, PF5 = 85, PF6 = 86, PF7 = 87;
            static constexpr int PF8 = 88, PF9 = 89, PF10 = 90, PF11 = 91, PF12 = 92, PF13 = 93, PF14 = 94, PF15 = 95;
            static constexpr int PG0 = 96, PG1 = 97, PG2 = 98, PG3 = 99, PG4 = 100, PG5 = 101, PG6 = 102, PG7 = 103;
            static constexpr int PG8 = 104, PG9 = 105, PG10 = 106, PG11 = 107, PG12 = 108, PG13 = 109, PG14 = 110, PG15 = 111;
            static constexpr int PH0 = 112, PH1 = 113, PH2 = 114, PH3 = 115, PH4 = 116, PH5 = 117, PH6 = 118, PH7 = 119;
            static constexpr int PH8 = 120, PH9 = 121, PH10 = 122, PH11 = 123, PH12 = 124, PH13 = 125, PH14 = 126, PH15 = 127;
            static constexpr int PI0 = 128, PI1 = 129, PI2 = 130, PI3 = 131, PI4 = 132, PI5 = 133, PI6 = 134, PI7 = 135;
            static constexpr int PI8 = 136, PI9 = 137, PI10 = 138, PI11 = 139, PI12 = 140, PI13 = 141, PI14 = 142, PI15 = 143;
            static constexpr int PJ0 = 144, PJ1 = 145, PJ2 = 146, PJ3 = 147, PJ4 = 148, PJ5 = 149, PJ6 = 150, PJ7 = 151;
            static constexpr int PJ8 = 152, PJ9 = 153, PJ10 = 154, PJ11 = 155, PJ12 = 156, PJ13 = 157, PJ14 = 158, PJ15 = 159;
            static constexpr int PK0 = 160, PK1 = 161, PK2 = 162, PK3 = 163, PK4 = 164, PK5 = 165, PK6 = 166, PK7 = 167;
            static constexpr int PK8 = 168, PK9 = 169, PK10 = 170, PK11 = 171, PK12 = 172, PK13 = 173, PK14 = 174, PK15 = 175;
            static constexpr int PL0 = 176, PL1 = 177, PL2 = 178, PL3 = 179, PL4 = 180, PL5 = 181, PL6 = 182, PL7 = 183;
            static constexpr int PL8 = 184, PL9 = 185, PL10 = 186, PL11 = 187, PL12 = 188, PL13 = 189, PL14 = 190, PL15 = 191;
            static constexpr int PM0 = 192, PM1 = 193, PM2 = 194, PM3 = 195, PM4 = 196, PM5 = 197, PM6 = 198, PM7 = 199;
            static constexpr int PM8 = 200, PM9 = 201, PM10 = 202, PM11 = 203, PM12 = 204, PM13 = 205, PM14 = 206, PM15 = 207;
            static constexpr int PN0 = 208, PN1 = 209, PN2 = 210, PN3 = 211, PN4 = 212, PN5 = 213, PN6 = 214, PN7 = 215;
            static constexpr int PN8 = 216, PN9 = 217, PN10 = 218, PN11 = 219, PN12 = 220, PN13 = 221, PN14 = 222, PN15 = 223;
            static constexpr int NONE = -1;  // no pin
        };

        // The pin's name, for example "PJ14"
        static std::string Name(int pin) {
            if (pin < 0 || pin > Pin::PN15) {
                return "#" + std::to_string(pin);
            }
            int port = pin / 16;
            return std::string("P") + static_cast<char>('A' + port) + std::to_string(pin % 16);
        }

        // Linux gpiochip number for the pin. On EPN256 each port is its own
        // gpiochip (A..N = 0..13).
        static int GetChipId(int pin) { return pin / 16; }

        // Line number within the gpiochip (0 to 15 on EPN256).
        static int GetLineId(int pin) { return pin % 16; }
    };
}  // namespace EPN256

// The EPN128 (Nuvoton MA35D0, Chili Pro) module. GPIO pin constants live
// here; the pay-for-use peripheral initializers (I2c, Can, SerialPort,
// Adc, Watchdog, StorageController) live in endpoint/EPN128.h - include
// that too when you need them. SPI and PWM are not bonded out on
// Chili Pro, so there is no EPN128::Spi or EPN128::Pwm: the chip-neutral
// SpiController and PwmController throw NotSupportedException on EPN128.
// MA35D0 and MA35D1 share the same pinctrl layout; EPN128 is the subset
// bonded on Chili Pro.
namespace EPN128 {
    // GPIO pins, for Devices::Gpio::GpioController
    struct Gpio {
        // The EPN128's pins: port * 16 + line, ports A to N
        struct Pin {
            static constexpr int PA0 = 0, PA1 = 1, PA2 = 2, PA3 = 3, PA4 = 4, PA5 = 5, PA6 = 6, PA7 = 7;
            static constexpr int PA8 = 8, PA9 = 9, PA10 = 10, PA11 = 11, PA12 = 12, PA13 = 13, PA14 = 14, PA15 = 15;
            static constexpr int PB0 = 16, PB1 = 17, PB2 = 18, PB3 = 19, PB4 = 20, PB5 = 21, PB6 = 22, PB7 = 23;
            static constexpr int PB8 = 24, PB9 = 25, PB10 = 26, PB11 = 27, PB12 = 28, PB13 = 29, PB14 = 30, PB15 = 31;
            static constexpr int PC0 = 32, PC1 = 33, PC2 = 34, PC3 = 35, PC4 = 36, PC5 = 37, PC6 = 38, PC7 = 39;
            static constexpr int PC8 = 40, PC9 = 41, PC10 = 42, PC11 = 43, PC12 = 44, PC13 = 45, PC14 = 46, PC15 = 47;
            static constexpr int PD0 = 48, PD1 = 49, PD2 = 50, PD3 = 51, PD4 = 52, PD5 = 53, PD6 = 54, PD7 = 55;
            static constexpr int PD8 = 56, PD9 = 57, PD10 = 58, PD11 = 59, PD12 = 60, PD13 = 61, PD14 = 62, PD15 = 63;
            static constexpr int PE0 = 64, PE1 = 65, PE2 = 66, PE3 = 67, PE4 = 68, PE5 = 69, PE6 = 70, PE7 = 71;
            static constexpr int PE8 = 72, PE9 = 73, PE10 = 74, PE11 = 75, PE12 = 76, PE13 = 77, PE14 = 78, PE15 = 79;
            static constexpr int PF0 = 80, PF1 = 81, PF2 = 82, PF3 = 83, PF4 = 84, PF5 = 85, PF6 = 86, PF7 = 87;
            static constexpr int PF8 = 88, PF9 = 89, PF10 = 90, PF11 = 91, PF12 = 92, PF13 = 93, PF14 = 94, PF15 = 95;
            static constexpr int PG0 = 96, PG1 = 97, PG2 = 98, PG3 = 99, PG4 = 100, PG5 = 101, PG6 = 102, PG7 = 103;
            static constexpr int PG8 = 104, PG9 = 105, PG10 = 106, PG11 = 107, PG12 = 108, PG13 = 109, PG14 = 110, PG15 = 111;
            static constexpr int PH0 = 112, PH1 = 113, PH2 = 114, PH3 = 115, PH4 = 116, PH5 = 117, PH6 = 118, PH7 = 119;
            static constexpr int PH8 = 120, PH9 = 121, PH10 = 122, PH11 = 123, PH12 = 124, PH13 = 125, PH14 = 126, PH15 = 127;
            static constexpr int PI0 = 128, PI1 = 129, PI2 = 130, PI3 = 131, PI4 = 132, PI5 = 133, PI6 = 134, PI7 = 135;
            static constexpr int PI8 = 136, PI9 = 137, PI10 = 138, PI11 = 139, PI12 = 140, PI13 = 141, PI14 = 142, PI15 = 143;
            static constexpr int PJ0 = 144, PJ1 = 145, PJ2 = 146, PJ3 = 147, PJ4 = 148, PJ5 = 149, PJ6 = 150, PJ7 = 151;
            static constexpr int PJ8 = 152, PJ9 = 153, PJ10 = 154, PJ11 = 155, PJ12 = 156, PJ13 = 157, PJ14 = 158, PJ15 = 159;
            static constexpr int PK0 = 160, PK1 = 161, PK2 = 162, PK3 = 163, PK4 = 164, PK5 = 165, PK6 = 166, PK7 = 167;
            static constexpr int PK8 = 168, PK9 = 169, PK10 = 170, PK11 = 171, PK12 = 172, PK13 = 173, PK14 = 174, PK15 = 175;
            static constexpr int PL0 = 176, PL1 = 177, PL2 = 178, PL3 = 179, PL4 = 180, PL5 = 181, PL6 = 182, PL7 = 183;
            static constexpr int PL8 = 184, PL9 = 185, PL10 = 186, PL11 = 187, PL12 = 188, PL13 = 189, PL14 = 190, PL15 = 191;
            static constexpr int PM0 = 192, PM1 = 193, PM2 = 194, PM3 = 195, PM4 = 196, PM5 = 197, PM6 = 198, PM7 = 199;
            static constexpr int PM8 = 200, PM9 = 201, PM10 = 202, PM11 = 203, PM12 = 204, PM13 = 205, PM14 = 206, PM15 = 207;
            static constexpr int PN0 = 208, PN1 = 209, PN2 = 210, PN3 = 211, PN4 = 212, PN5 = 213, PN6 = 214, PN7 = 215;
            static constexpr int PN8 = 216, PN9 = 217, PN10 = 218, PN11 = 219, PN12 = 220, PN13 = 221, PN14 = 222, PN15 = 223;
            static constexpr int NONE = -1;  // no pin
        };

        // The pin's name, for example "PC0"
        static std::string Name(int pin) {
            if (pin < 0 || pin > Pin::PN15) {
                return "#" + std::to_string(pin);
            }
            int port = pin / 16;
            return std::string("P") + static_cast<char>('A' + port) + std::to_string(pin % 16);
        }

        // Linux gpiochip number for the pin. On EPN128 each port is its own
        // gpiochip (A..N = 0..13).
        static int GetChipId(int pin) { return pin / 16; }

        // Line number within the gpiochip (0 to 15 on EPN128).
        static int GetLineId(int pin) { return pin % 16; }
    };
}  // namespace EPN128

}  // namespace GHIElectronics::Endpoint::Core
